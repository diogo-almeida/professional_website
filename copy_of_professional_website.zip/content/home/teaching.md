+++
# Custom widget.
# An example of using the custom widget to create your own homepage section.
# To create more sections, duplicate this file and edit the values below as desired.
widget = "custom"
active = true
date = 2016-04-20T00:00:00

# Note: a full width section format can be enabled by commenting out the `title` and `subtitle` with a `#`.
title = "Teaching"
subtitle = ""

# Order that this section will appear in.
weight = 60

+++

During the academic year 2019-2020 year, I will be on sabbatical.

Courses that I have taught in the past at NYUAD and may teach again at some point in the future:

- PSYCH-UH 1001: Introduction to Psychology
- PSYCH-UH 2212: Psychology of Language
- PSYCH-UH 2410: Cognition
- PSYCH-UH 3615EQ: Lab in Psychology of Language
- CDAD-UH 1007EQ: The Mind
