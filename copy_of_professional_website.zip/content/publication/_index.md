+++
title = "Publications"
date = 2018-07-28T00:00:00
math = false
highlight = false

# List format.
#   0 = Simple
#   1 = Detailed
#   2 = APA
#   3 = MLA
list_format = 2

# Optional featured image (relative to `static/img/` folder).
[header]
image = ""
caption = ""
+++

{{% staticref "files/diogoalmeida.bib" %}}All my citations as a single bibtex file{{% /staticref %}}.
